# @jianyiagi/dsh-prompt-enhancer

> DSH（DeepSeek Harness）Web 端插件：**输入框一键优化提示词**。
> 有内容时，模型选择器左侧出现一个闪光按钮；点一下，模型把提示词改写得更清晰、更可执行，结果直接替换输入框草稿。

---

## 功能

- **一键增强**：优化表达 + 结构化（自然段落优先），消除歧义与口语化，明确目标 / 对象 / 约束 / 期望输出
- **忠于原文**：保留原意与语言，不编造原文没有的信息；代码、命令、路径、变量名、字段名**原样保留**
- **无冗余**：不写「未指定 / 未提供」占位，各部分不重复，长度不明显超过原文
- **直接可用**：结果写回输入框，不满意可直接编辑器撤销
- **双语**：界面文案随 DSH 语言（中文 / English）

---

## 安装

### 桌面端（Electron App）

**推荐**：左侧栏「**插件**」页 → 安装 bundle → 填入包名：

```
@jianyiagi/dsh-prompt-enhancer
```

装完**完全退出 App 再重新启动**（不是刷新页面）。

### CLI / Web 端

```powershell
dsh plugin --profile <你的profile> add @jianyiagi/dsh-prompt-enhancer
```

若 `dsh` 不在 PATH，用 DSH 安装目录下的 bin：

```powershell
node "<dsh-app>\lib\bin.js" plugin --profile=<profile> add @jianyiagi/dsh-prompt-enhancer
```

> `<dsh-app>` = DSH 安装目录下的 `resources\dsh\app`。
> 若装完没生效，说明包已安装但 **bundle 未被选中**：在「插件」页勾选它，或把包名加入 profile 的 `dsh.profile.bundles` 后重启。

---

## 使用

| 入口 | 行为 |
|---|---|
| 输入框工具行的闪光按钮（模型选择器左侧） | 草稿非空时出现 → 单击 → 转圈 → 草稿被增强结果替换 |
| 斜杠命令 `/prompt-enhance <文本>` | 结果以命令结果行展示，**不写回草稿**（附带能力） |

增强失败时按钮左侧显示一行错误（4 秒后自动消失）。

---

## 配置：固定增强所用模型（推荐）

默认**跟随会话当前模型**。若想更快，可在 profile 补丁里固定一个轻量模型：

```yaml
- insert:
    - id: prompt-enhancer
      name: '@jianyiagi/dsh-prompt-enhancer'
      config:
        provider: <provider-id>
        model: <model-id>
```

两个字段必须同时提供才生效；删掉 `config` 即恢复跟随会话模型。

> 为什么建议固定：增强是**生成密集型**调用。实测同一段提示词，大模型需 25～48 秒，轻量模型仅 4～6 秒（约 6～12 倍）。输出很短，瓶颈完全在模型思考。

---

## 已知限制（不是 bug）

1. **每次增强会在对话流留一行** `prompt-enhance · <结果预览>`。原因：插件唯一的客户端→宿主通道是命令注册表，注册表强制记录 `command/run`/`command/done`，而 Chat 层的命令行展示是宿主内建行为、未开插件级隐藏接口。该行不影响模型历史、不计 token。
2. **引用芯片会退化为纯文本**：草稿里的 `@文件` 引用在整体替换后变成普通文本。
3. **直接替换、无预览**：不满意请用编辑器撤销。
4. **仅文本增强**：不改动附件；单次输入上限 24 KB，超时 60 秒。

---

## 卸载

桌面端：「插件」页卸载。CLI：

```powershell
dsh plugin --profile <profile> remove @jianyiagi/dsh-prompt-enhancer
```

---

## 它怎么工作

```
输入框草稿 → 按钮（会话作用域槽位 conversation.input.right）
   → ctx.remote.commands.execute("/prompt-enhance <草稿>")
   → 宿主命令用 ctx.llm.stream 调模型（凭据走你的账户登录态，插件不接触 API Key）
   → 结果经命令结果回传 → inputActions.setDraft(结果)
```

- 不读取、不存储、不上传任何 API Key
- 不发送除提示词本身以外的任何内容给模型
- 开源免费（MIT）

---

**版本**：1.0.1 ｜ **仓库**：https://github.com/JianYiAG/dsh-prompt-enhancer ｜ **维护者**：@jianyiagi
